<?php
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Message\ResponseInterface;
include 'dbConfig.php';
require 'autoload.php';

$app = new Slim\App();

$app->post('/login','login');
$app->post('/signup','signup');
$app->post('/checkUserExist','checkUserExist');
$app->post('/product','product');
$app->get('/userlist','userlist');
$app->get('/productlist','productlist');
$app->run();

function login($request) {
    //print_r($request);exit;
    $headers = $request->request->headers;
print_r($headers);
// Get the ACCEPT_CHARSET header
$charset = $request->request->headers->get('ACCEPT_CHARSET');
print_r("expression");
print_r($charset);exit;
  $login=$request->getParsedBody();
	 try {
			$db = getDB();
			$stmt = $db->prepare("SELECT * FROM user WHERE username=:username1 AND password=:password1");
			$stmt->bindValue(':username1', $login['username'], PDO::PARAM_STR);
			$stmt->bindValue(':password1', $login['password'], PDO::PARAM_STR);
			$stmt->execute();
			$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
			//echo json_encode($rows);
		    
foreach ($rows as $data) {
		$type=$data['id'];
		$active = $data['is_active'];
                $member = $data['paid_member'];
		}
			
			    /****************Gerating token and updating the db***************/
    $cur_time=date("Y-m-d H:i:s");
    //$duration='+10 minutes';
    //$expires = date('Y-m-d H:i:s', strtotime($duration, strtotime($cur_time)));
    $token = md5(microtime() . uniqid(). rand());

    $sql = "UPDATE user SET token = :token, expires = ADDTIME(now(), '1000') WHERE username=:username1 AND password=:password1";
    $stmt = $db->prepare($sql);
    $stmt->bindValue(':username1', $login['username'], PDO::PARAM_STR);
			$stmt->bindValue(':password1', $login['password'], PDO::PARAM_STR);
    $stmt->bindParam("token", $token);
    $status = $stmt->execute();

    /******************************/
		$db = null;

		if(count($rows)) {
			echo '{"status": "success","Active Status": "'.$active.'","Paid member": "'.$member.'"}';
		}
		else
			echo '{"status": "failed"}';
	}catch(PDOException $e) {
				echo '{"error":{"text":'. $e->getMessage() .'}}';
			} 
	
}
function userlist() {
  //  print_r($request->getParsedBody());exit;
 
	 try {
			$db = getDB();
			$stmt = $db->prepare("SELECT * FROM user");
			$stmt->execute();
			$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
			echo json_encode($rows);
		    } catch(PDOException $e) {
				echo '{"error":{"text":'. $e->getMessage() .'}}';
			} 
	
}
function productlist() {
  //  print_r($request->getParsedBody());exit;
 
	 try {
			$db = getDB();
			$stmt = $db->prepare("SELECT * FROM product");
			$stmt->execute();
			$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
			echo json_encode($rows);
		    } catch(PDOException $e) {
				echo '{"error":{"text":'. $e->getMessage() .'}}';
			} 
	
}
// function signup($request){
//  
//        try {
//            
////            $check =checkUserExist($request);
////            if($check['status'] == 'error') {
////                $status = $check['status'];
////                print_r($status);
////            } else {
//            $db = getDB();
//            $user=$request->getParsedBody();
//           // print_r($user);
//            $sql = "INSERT INTO user(`username`, `password`, `email_id`) VALUES ( :username, :password,  :email_id)";
//            $stmt = $db->prepare($sql);
//           
//            $stmt->bindParam("username", $user['username']);
//            $stmt->bindParam("password", $user['password']);
//            $stmt->bindParam("email_id", $user['email_id']);
//            //$stmt->bindParam("paid_member", $user['paid_member']);
//            //$stmt->bindParam("user_type_id", $user['user_type_id']);
//            //$stmt->bindParam("status", $user['status']);
//            $stmt->execute();
//            //$db = null;
//              
//                    //$data = array('status'=>'success', 'msg'=>"You have been registered successfully login now.", 'result'=>'');
//            echo '{"status":"success"}';
//            //print_r($data);
//            //}
//        } catch(PDOException $e) {
//            echo '{"error":{"text":'. $e->getMessage() .'}}';
//        }
//}
//

function checkUserExist($request) {
    $user=$request->getParsedBody();
    $username = $user['username'];
   // print_r($username);
     try {
        $sql = "SELECT username FROM user WHERE username =:username";
        $db = getDB();
        $smt = $db->prepare($sql);
        $smt->bindParam("username", $username);
        $smt->execute();
        $count = $smt->rowCount();
        //$db = null;
        if($count>0) {
          throw new exception("Username already exist.");
        }       
        $data = array('status'=>'success');
        } catch (Exception $e) {
             $data = array('status'=>'error', 'msg'=>$e->getMessage()); 
        } finally {
            //print_r($data);
            return $data;
            
        }
    }


 function product($request){
 $today = date("Y-m-d H:i:s");
 $product=$request->getParsedBody();
  $sql = "INSERT INTO `product`(`product_name`, `quantity`, `price`,`category`, `des`,  `created_at`,`status`) VALUES ( :product_name, :qty,  :price, :category, :des, :created_at, :status)";
  
        try {
            $db = getDB();
            
            $stmt = $db->prepare($sql);
           
            $stmt->bindParam("product_name", $product['pro_name']);
            $stmt->bindParam("price", $product['price']);
			$stmt->bindParam("qty", $product['qty']);
            $stmt->bindParam("category", $product['category']);
			$stmt->bindParam("des", $product['des']);
            $stmt->bindParam("status", $product['status']);
			$stmt->bindParam("created_at", $today);
            $status = $stmt->execute();
            $db = null;
            echo '{"status":'.$status.'}';
        } catch(PDOException $e) {
            echo '{"error":{"text":'. $e->getMessage() .'}}';
        }
}
function signup($request){
 //$today = date("Y-m-d H:i:s");
    print_r($request->getParsedBody());
        
    $user = $request->getParsedBody();
    $sql = "INSERT INTO `user`(`username`, `password`, `email_id`) VALUES ( :username, :password,  :email_id)";
  
        try {
            $db = getDB();
            
            $stmt = $db->prepare($sql);
           
            $stmt->bindValue("username", $user['username'],PDO::PARAM_STR);
            $stmt->bindValue("password", $user['password'],PDO::PARAM_STR);
            $stmt->bindValue("email_id", $user['email_id'],PDO::PARAM_STR);
            $status = $stmt->execute();
            $db = null;
            echo '{"status":'.$status.'}';
        } catch(PDOException $e) {
            echo '{"error":{"text":'. $e->getMessage() .'}}';
        }
}